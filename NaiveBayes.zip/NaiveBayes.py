#Alex Koumandarakis
#CS 599
#PRG 3: Naive Bayes

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import math

def main():
    #Load the training features data
    df_trainFeat = pd.read_csv('train-features.txt', sep=" ", header=None)
    df_trainFeat.columns = ["MsgNum", "WordID", "NumOccur"]

    #Load the training labels data
    df_trainLabels = pd.read_csv('train-labels.txt', sep=" ", header=None)

    #Construct dictionaries for number of spam and ham messages each word appears in
    #Key: WordID, Value: number of messages word appears in
    hamDict = {}
    spamDict = {}
    for index, row in df_trainFeat.iterrows():
        #The word is in a ham message
        if df_trainLabels.loc[row['MsgNum']-1,0] == 0:
            if row['WordID'] in hamDict:
                hamDict[row['WordID']] += 1
            else:
                hamDict[row['WordID']] = 1
        #The word is in a spam message
        elif df_trainLabels.loc[row['MsgNum']-1,0] == 1:
            if row['WordID'] in spamDict:
                spamDict[row['WordID']] += 1
            else:
                spamDict[row['WordID']] = 1

    #Load the testing features data
    df_testFeat = pd.read_csv('test-features.txt', sep=" ", header=None)
    df_testFeat.columns = ["MsgNum", "WordID", "NumOccur"]

    #Load the testing labels data
    df_testLabels = pd.read_csv('test-labels.txt', sep=" ", header=None)

    #Get the number of spam and ham messages
    numSpam = len((df_testLabels.loc[df_testLabels[0] == 1]).index)
    numHam =  len((df_testLabels.loc[df_testLabels[0] == 0]).index)
    numMsgs = len(df_testLabels.index);

    #Calculate P(spam) and P(ham)
    P_ham = numHam/numMsgs
    P_spam = numSpam/numMsgs
    
    #Iterate through each message and calculate P(spam|x) and P(ham|x)
    numCorrect = 0
    for i in range(1, numMsgs+1):
        msg = df_testFeat.loc[df_testFeat['MsgNum'] == i]
        prod_pxSpam = 1.0
        prod_pxHam = 1.0
        #Iterate through each word and find P(xi|spam) and P(xi|ham)
        for index, row in msg.iterrows():
            xi = row['WordID']

            P_xiSpam = 0.5
            if xi in spamDict:
                P_xiSpam = (spamDict[xi]+1) / (numSpam+2)
            prod_pxSpam *= P_xiSpam

            P_xiHam = 0.5
            if xi in hamDict:
                P_xiHam = (hamDict[xi]+1) / (numHam+2)
            prod_pxHam *= P_xiHam

        #Find P(spam|x) and P(ham|x)
        P_hamx = 0
        P_spamx = 0
        if (prod_pxHam == 0 and prod_pxSpam == 0):
            P_hamx = 0.5
            P_spamx = 0.5
        else:
            P_hamx = (prod_pxHam * P_ham) / ((prod_pxHam * P_ham) + (prod_pxSpam*P_spam))
            P_spamx = (prod_pxSpam * P_spam) / ((prod_pxSpam * P_spam) + (prod_pxHam*P_ham))

        #Count number of correctly classified messages
        if (P_hamx >= P_spamx and df_testLabels.loc[i-1,0] == 0):
            numCorrect += 1 #Message correctly classified as ham
        if (P_hamx < P_spamx and df_testLabels.loc[i-1,0] == 1):
            numCorrect += 1 #Message correctly classified as spam

    accuracy = numCorrect / numMsgs
    print("Accuracy: " + str(accuracy))
    print(str(numCorrect) + " messages correctly classified out of " + str(numMsgs) + ".")
    

if __name__ == "__main__":
    main()
